﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class endingaaa : MonoBehaviour
{
    // Start is called before the first frame update
    void Awake()
    {

        SceneManager.LoadScene("09.Ending_3_1", LoadSceneMode.Additive);

    }
}
