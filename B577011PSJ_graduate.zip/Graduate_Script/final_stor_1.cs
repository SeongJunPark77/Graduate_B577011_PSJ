﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class final_stor_1 : MonoBehaviour
{
    // Start is called before the first frame update
    void Awake()
    {

            SceneManager.LoadScene("final_stor3", LoadSceneMode.Additive);


    }
}
